//
//  Organization.m
//  SBJsonSample
//
//  Created by venkat kongara on 3/15/17.
//  Copyright © 2017 venkat kongara. All rights reserved.
//

#import "Organization.h"

@implementation Organization

- (id)proxyForJson {
    return [NSDictionary dictionaryWithObjectsAndKeys:
            _name, @"organizationName",
            _people, @"people",
            nil];
}

@end
