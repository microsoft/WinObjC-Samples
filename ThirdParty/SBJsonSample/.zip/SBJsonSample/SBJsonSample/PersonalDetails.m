//
//  TestModel1.m
//  SBJsonSample
//
//  Created by venkat kongara on 3/15/17.
//  Copyright © 2017 venkat kongara. All rights reserved.
//

#import "PersonalDetails.h"

@implementation PersonalDetails

- (id)proxyForJson {
    return [NSDictionary dictionaryWithObjectsAndKeys:
            _name, @"name",
            [[NSNumber alloc] initWithLong:self.phone], @"phone",
            _email, @"email",
            nil];
}

@end
