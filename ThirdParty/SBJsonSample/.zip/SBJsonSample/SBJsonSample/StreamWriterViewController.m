//
//  StreamWriterViewController.m
//  SBJsonSample
//
//  Created by venkat kongara on 3/15/17.
//  Copyright © 2017 venkat kongara. All rights reserved.
//

#import "StreamWriterViewController.h"
#import "Organization.h"

@interface StreamWriterViewController () {
    UITableView* APITestTableView;
    NSArray* buttonArray;
    UITextView* _delegateOutputTextView;
    SBJson5StreamWriter* jsonWriter;
}

@end

@implementation StreamWriterViewController

- (void)_clear {
    void (^block)() = ^{
        @synchronized(_delegateOutputTextView) {
            _delegateOutputTextView.text = @"";
        }
    };
    dispatch_async(dispatch_get_main_queue(), block);
}

- (void)_printOutput:(id)format, ... {
    va_list ap;
    va_start(ap, format);
    
    NSString* newString = [[NSString alloc] initWithFormat:[format description] arguments:ap];
    void (^block)() = ^{
        @synchronized(_delegateOutputTextView) {
            if ([format isKindOfClass:[NSAttributedString class]]) {
                NSMutableAttributedString* textViewString = [_delegateOutputTextView.attributedText mutableCopy];
                [textViewString appendAttributedString:format];
                [textViewString appendAttributedString:[[NSAttributedString alloc] initWithString:@"\n"]];
                _delegateOutputTextView.attributedText = textViewString;
            }else {
                _delegateOutputTextView.text = [_delegateOutputTextView.text stringByAppendingString:newString];
                _delegateOutputTextView.text = [_delegateOutputTextView.text stringByAppendingString:@"\n"];
            }
            if(_delegateOutputTextView.text.length > 0 ) {
                NSRange bottom = NSMakeRange(_delegateOutputTextView.text.length -1, 1);
                [_delegateOutputTextView scrollRangeToVisible:bottom];
            }
        }
    };
    dispatch_async(dispatch_get_main_queue(), block);
    va_end(ap);
}

-(NSString*)readJsonFrom:(NSString*)file withExtension:(NSString*)extension {
    NSString *filepath = [[NSBundle mainBundle] pathForResource:file ofType:extension];
    NSError *error;
    NSString *fileContents = [NSString stringWithContentsOfFile:filepath encoding:NSUTF8StringEncoding error:&error];
    
    if (error)
        return [NSString stringWithFormat:@"Error reading file: %@", error.localizedDescription];
    else
        return fileContents;
}

-(void)constructViewWithTableView {
    buttonArray = [[NSArray alloc] initWithObjects:@"write object",@"write array",@"write object open",@"write object close",@"write Array open",@"write Array close",@"write null",@"write bool",@"write number",@"write string",nil];
    
    //defines all views
    _delegateOutputTextView = [[UITextView alloc] init];
    _delegateOutputTextView.translatesAutoresizingMaskIntoConstraints = false;
    [_delegateOutputTextView setBackgroundColor:[UIColor whiteColor]];
    [_delegateOutputTextView setEditable:NO];
    _delegateOutputTextView.delegate = self;
    
    UIView* container = [[UIView alloc] init];
    container.translatesAutoresizingMaskIntoConstraints = false;
    [container setTag:000];
    
    UILabel* label1 = [[UILabel alloc] init];
    [label1 setText:@"Please observe console for output."];
    [label1 setLineBreakMode:NSLineBreakByWordWrapping];
    [label1 setNumberOfLines:0];
    label1.translatesAutoresizingMaskIntoConstraints = false;
    [label1 setBackgroundColor:[UIColor clearColor]];
    [label1 setTextAlignment:NSTextAlignmentCenter];
    
    APITestTableView = (UITableView*)[[UITableView alloc] init];
    [APITestTableView setBackgroundColor:[UIColor clearColor]];
    APITestTableView.delegate = self;
    APITestTableView.dataSource = self;
    APITestTableView.translatesAutoresizingMaskIntoConstraints = false;
    APITestTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    
    [container setBackgroundColor:[UIColor colorWithWhite:0.5 alpha:1.0]];
    [APITestTableView setBackgroundColor:[UIColor clearColor]];
    
    [container addSubview:APITestTableView];
    [[self view] addSubview:container];
    [[self view] addSubview:_delegateOutputTextView];
    
    
    NSLayoutConstraint *topCLayoutConstraints = [NSLayoutConstraint constraintWithItem:[self view]
                                                                             attribute:NSLayoutAttributeTop
                                                                             relatedBy:NSLayoutRelationEqual
                                                                                toItem:container
                                                                             attribute:NSLayoutAttributeTop
                                                                            multiplier:1.f constant:0.f];
    NSLayoutConstraint *bottomCLayoutConstraints = [NSLayoutConstraint constraintWithItem:container
                                                                                attribute:NSLayoutAttributeBottom
                                                                                relatedBy:NSLayoutRelationEqual
                                                                                   toItem:_delegateOutputTextView
                                                                                attribute:NSLayoutAttributeTop
                                                                               multiplier:1.f constant:0.f];
    NSLayoutConstraint *leftCLayoutConstraints = [NSLayoutConstraint constraintWithItem:[self view]
                                                                              attribute:NSLayoutAttributeLeft
                                                                              relatedBy:NSLayoutRelationEqual
                                                                                 toItem:container
                                                                              attribute:NSLayoutAttributeLeft
                                                                             multiplier:1.f constant:0.f];
    NSLayoutConstraint *rightCLayoutConstraints = [NSLayoutConstraint constraintWithItem:[self view]
                                                                               attribute:NSLayoutAttributeRight
                                                                               relatedBy:NSLayoutRelationEqual
                                                                                  toItem:container
                                                                               attribute:NSLayoutAttributeRight
                                                                              multiplier:1.f constant:0.f];
    
    NSLayoutConstraint *heightLayoutConstraints = [NSLayoutConstraint constraintWithItem:_delegateOutputTextView
                                                                               attribute:NSLayoutAttributeHeight
                                                                               relatedBy:NSLayoutRelationEqual
                                                                                  toItem:nil
                                                                               attribute:NSLayoutAttributeNotAnAttribute
                                                                              multiplier:1.f constant:250.f];
    NSLayoutConstraint *leftTLayoutConstraints = [NSLayoutConstraint constraintWithItem:[self view]
                                                                              attribute:NSLayoutAttributeLeft
                                                                              relatedBy:NSLayoutRelationEqual
                                                                                 toItem:_delegateOutputTextView
                                                                              attribute:NSLayoutAttributeLeft
                                                                             multiplier:1.f constant:0.f];
    NSLayoutConstraint *rightTLayoutConstraints = [NSLayoutConstraint constraintWithItem:[self view]
                                                                               attribute:NSLayoutAttributeRight
                                                                               relatedBy:NSLayoutRelationEqual
                                                                                  toItem:_delegateOutputTextView
                                                                               attribute:NSLayoutAttributeRight
                                                                              multiplier:1.f constant:0.f];
    NSLayoutConstraint *bottomTLayoutConstraints = [NSLayoutConstraint constraintWithItem:_delegateOutputTextView
                                                                                attribute:NSLayoutAttributeBottom
                                                                                relatedBy:NSLayoutRelationEqual
                                                                                   toItem:[self view]
                                                                                attribute:NSLayoutAttributeBottom
                                                                               multiplier:1.f constant:0.f];
    
    NSDictionary *views = NSDictionaryOfVariableBindings(APITestTableView);
    [container addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:
                               @"H:|[APITestTableView]|" options:0 metrics:nil views:views]];
    [container addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:
                               @"V:|-40-[APITestTableView]-0-|" options:0 metrics:nil views:views]];
    
    [[self view] addConstraint:topCLayoutConstraints];
    [[self view] addConstraint:bottomCLayoutConstraints];
    [[self view] addConstraint:leftCLayoutConstraints];
    [[self view] addConstraint:rightCLayoutConstraints];
    [[self view] addConstraint:heightLayoutConstraints];
    [[self view] addConstraint:leftTLayoutConstraints];
    [[self view] addConstraint:rightTLayoutConstraints];
    [[self view] addConstraint:bottomTLayoutConstraints];
}

- (BOOL)textViewShouldBeginEditing:(UITextView *)textView {
    return NO;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:false];
    __weak typeof(self) weakSelf = self;
    switch (indexPath.row) {
        case 0: {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                if(![jsonWriter writeObject:[NSDictionary dictionaryWithObjectsAndKeys:@"sample name",@"name", nil]]){
                    [weakSelf _printOutput:jsonWriter.error];
                    [weakSelf _printOutput:@"try again. we have opened a new stream."];
                    [weakSelf initializeWriter];
                }
            });
            break;
        }
        case 1: {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                if(![jsonWriter writeArray:[NSArray arrayWithObjects:@"one",@"two",@"three", nil]]){
                    [weakSelf _printOutput:jsonWriter.error];
                    [weakSelf _printOutput:@"try again. we have opened a new stream."];
                    [weakSelf initializeWriter];
                }
            });
            break;
        }
        case 2: {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                if(![jsonWriter writeObjectOpen]){
                    [weakSelf _printOutput:jsonWriter.error];
                    [weakSelf _printOutput:@"try again. we have opened a new stream."];
                    [weakSelf initializeWriter];
                }
            });
            break;
        }
        case 3: {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                if(![jsonWriter writeObjectClose]){
                    [weakSelf _printOutput:jsonWriter.error];
                    [weakSelf _printOutput:@"try again. we have opened a new stream."];
                    [weakSelf initializeWriter];
                }
            });
            break;
        }
        case 4: {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                if(![jsonWriter writeArrayOpen]){
                    [weakSelf _printOutput:jsonWriter.error];
                    [weakSelf _printOutput:@"try again. we have opened a new stream."];
                    [weakSelf initializeWriter];
                }
            });
            break;
        }
        case 5: {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                if(![jsonWriter writeArrayClose]){
                    [weakSelf _printOutput:jsonWriter.error];
                    [weakSelf _printOutput:@"try again. we have opened a new stream."];
                    [weakSelf initializeWriter];
                }
            });
            break;
        }
        case 6: {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                if(![jsonWriter writeNull]){
                    [weakSelf _printOutput:jsonWriter.error];
                    [weakSelf _printOutput:@"try again. we have opened a new stream."];
                    [weakSelf initializeWriter];
                }
            });
            break;
        }
        case 7: {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                if(![jsonWriter writeBool:true]){
                    [weakSelf _printOutput:jsonWriter.error];
                    [weakSelf _printOutput:@"try again. we have opened a new stream."];
                    [weakSelf initializeWriter];
                }
            });
            break;
        }
        case 8: {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                if(![jsonWriter writeNumber:[[NSNumber alloc] initWithInt:1000]]){
                    [weakSelf _printOutput:jsonWriter.error];
                    [weakSelf _printOutput:@"try again. we have opened a new stream."];
                    [weakSelf initializeWriter];
                }
            });
            break;
        }
        case 9: {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                if(![jsonWriter writeString:@"sample string"]){
                    [weakSelf _printOutput:jsonWriter.error];
                    [weakSelf _printOutput:@"try again. we have opened a new stream."];
                    [weakSelf initializeWriter];
                }
            });
            break;
        }
        default:
            break;
    }
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [buttonArray count];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSAttributedString* string = [[NSAttributedString alloc] initWithString:[buttonArray objectAtIndex:indexPath.row]];
    CGRect rect = [string boundingRectWithSize:CGSizeMake(100, 100) options:NSStringDrawingUsesDeviceMetrics context:nil];
    return rect.size.height + 40;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString* cellID = @"buttonCell";
    UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    [cell setBackgroundColor:[UIColor clearColor]];
    [[cell textLabel] setNumberOfLines:0];
    [[cell textLabel] setText:[buttonArray objectAtIndex:[indexPath row]]];
    [[cell textLabel] setTextAlignment:NSTextAlignmentCenter];
    return cell;
}

-(void)initializeWriter {
    jsonWriter = [SBJson5StreamWriter writerWithDelegate:self maxDepth:32 humanReadable:true sortKeys:true sortKeysComparator:^NSComparisonResult(id  _Nonnull obj1, id  _Nonnull obj2) {
        return [(NSString*)obj1 length] > [(NSString*)obj2 length];
    }];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self constructViewWithTableView];
    [self setTitle:@"SBJson5StreamWriter"];
    [self initializeWriter];
}

-(void)writer:(SBJson5StreamWriter *)writer appendBytes:(const void *)bytes length:(NSUInteger)length {
    NSMutableAttributedString* outString = [[NSMutableAttributedString alloc] init];
    [outString appendAttributedString:[[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"appended to writer stream with data of size :"]]];
    [outString addAttribute:NSForegroundColorAttributeName value:[UIColor blueColor] range:NSMakeRange(0, [outString length])];
    [outString appendAttributedString:[[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@" %lu",(unsigned long)length]]];
    __weak typeof(self) weakSelf = self;
    dispatch_async(dispatch_get_main_queue(), ^{
        [weakSelf _printOutput:outString];
    });
}

@end
