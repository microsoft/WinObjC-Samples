//
//  TestModel1.h
//  SBJsonSample
//
//  Created by venkat kongara on 3/15/17.
//  Copyright © 2017 venkat kongara. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PersonalDetails : NSObject

@property(atomic,strong) NSString* name;
@property(atomic) long phone;
@property(atomic,strong) NSString* email;

@end
