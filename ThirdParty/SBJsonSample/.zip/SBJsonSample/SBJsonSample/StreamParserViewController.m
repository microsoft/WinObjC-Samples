//
//  StreamParseViewController.m
//  SBJsonSample
//
//  Created by venkat kongara on 3/14/17.
//  Copyright © 2017 venkat kongara. All rights reserved.
//

#import "StreamParserViewController.h"

@interface StreamParserViewController (){
    UITableView* APITestTableView;
    NSArray* buttonArray;
    UITextView* _delegateOutputTextView;
    NSMutableData *data;
}

@end

@implementation StreamParserViewController

- (void)_clear {
    void (^block)() = ^{
        @synchronized(_delegateOutputTextView) {
            _delegateOutputTextView.text = @"";
        }
    };
    dispatch_async(dispatch_get_main_queue(), block);
}

- (void)_printOutput:(id)format, ... {
    va_list ap;
    va_start(ap, format);
    
    NSString* newString = [[NSString alloc] initWithFormat:[format description] arguments:ap];
    void (^block)() = ^{
        @synchronized(_delegateOutputTextView) {
            if ([format isKindOfClass:[NSAttributedString class]]) {
                NSMutableAttributedString* textViewString = [_delegateOutputTextView.attributedText mutableCopy];
                [textViewString appendAttributedString:format];
                [textViewString appendAttributedString:[[NSAttributedString alloc] initWithString:@"\n"]];
                _delegateOutputTextView.attributedText = textViewString;
            }else {
                _delegateOutputTextView.text = [_delegateOutputTextView.text stringByAppendingString:newString];
                _delegateOutputTextView.text = [_delegateOutputTextView.text stringByAppendingString:@"\n"];
            }
            if(_delegateOutputTextView.text.length > 0 ) {
                NSRange bottom = NSMakeRange(_delegateOutputTextView.text.length -1, 1);
                [_delegateOutputTextView scrollRangeToVisible:bottom];
            }
        }
    };
    dispatch_async(dispatch_get_main_queue(), block);
    va_end(ap);
}

-(void)printColoredDebugInfo:(NSString*) string using:(UIColor*)color {
    __weak typeof(self) weakSelf = self;
    NSMutableAttributedString* printString = [[NSMutableAttributedString alloc] init];
    [printString appendAttributedString:[[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@", string]]];
    [printString addAttribute:NSForegroundColorAttributeName value:color range:NSMakeRange(0, [printString length])];
    dispatch_async(dispatch_get_main_queue(), ^{
        [weakSelf _printOutput:printString];
    });
}

-(NSString*)readJsonFrom:(NSString*)file withExtension:(NSString*)extension {
    NSString *filepath = [[NSBundle mainBundle] pathForResource:file ofType:extension];
    NSError *error;
    NSString *fileContents = [NSString stringWithContentsOfFile:filepath encoding:NSUTF8StringEncoding error:&error];
    
    if (error)
        return [NSString stringWithFormat:@"Error reading file: %@", error.localizedDescription];
    else
        return fileContents;
}

-(void)constructViewWithTableView {
    [_delegateOutputTextView setEditable:NO];
    buttonArray = [[NSArray alloc] initWithObjects:@"parse simple array",@"parse initial half data stream",@"parse remaining half data Stream to complete",@"parse large DataStream",nil];
    
    //defines all views
    _delegateOutputTextView = [[UITextView alloc] init];
    _delegateOutputTextView.translatesAutoresizingMaskIntoConstraints = false;
    [_delegateOutputTextView setBackgroundColor:[UIColor whiteColor]];
    [_delegateOutputTextView setEditable:NO];
    _delegateOutputTextView.delegate = self;
    
    UIView* container = [[UIView alloc] init];
    container.translatesAutoresizingMaskIntoConstraints = false;
    [container setTag:000];
    
    UILabel* label1 = [[UILabel alloc] init];
    [label1 setText:@"Please observe console for output."];
    [label1 setLineBreakMode:NSLineBreakByWordWrapping];
    [label1 setNumberOfLines:0];
    label1.translatesAutoresizingMaskIntoConstraints = false;
    [label1 setBackgroundColor:[UIColor clearColor]];
    [label1 setTextAlignment:NSTextAlignmentCenter];
    
    APITestTableView = (UITableView*)[[UITableView alloc] init];
    [APITestTableView setBackgroundColor:[UIColor clearColor]];
    APITestTableView.delegate = self;
    APITestTableView.dataSource = self;
    APITestTableView.translatesAutoresizingMaskIntoConstraints = false;
    APITestTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    
    [container setBackgroundColor:[UIColor colorWithWhite:0.5 alpha:1.0]];
    [APITestTableView setBackgroundColor:[UIColor clearColor]];
    
    [container addSubview:APITestTableView];
    [[self view] addSubview:container];
    [[self view] addSubview:_delegateOutputTextView];
    
    
    NSLayoutConstraint *topCLayoutConstraints = [NSLayoutConstraint constraintWithItem:[self view]
                                                                             attribute:NSLayoutAttributeTop
                                                                             relatedBy:NSLayoutRelationEqual
                                                                                toItem:container
                                                                             attribute:NSLayoutAttributeTop
                                                                            multiplier:1.f constant:0.f];
    NSLayoutConstraint *bottomCLayoutConstraints = [NSLayoutConstraint constraintWithItem:container
                                                                                attribute:NSLayoutAttributeBottom
                                                                                relatedBy:NSLayoutRelationEqual
                                                                                   toItem:_delegateOutputTextView
                                                                                attribute:NSLayoutAttributeTop
                                                                               multiplier:1.f constant:0.f];
    NSLayoutConstraint *leftCLayoutConstraints = [NSLayoutConstraint constraintWithItem:[self view]
                                                                              attribute:NSLayoutAttributeLeft
                                                                              relatedBy:NSLayoutRelationEqual
                                                                                 toItem:container
                                                                              attribute:NSLayoutAttributeLeft
                                                                             multiplier:1.f constant:0.f];
    NSLayoutConstraint *rightCLayoutConstraints = [NSLayoutConstraint constraintWithItem:[self view]
                                                                               attribute:NSLayoutAttributeRight
                                                                               relatedBy:NSLayoutRelationEqual
                                                                                  toItem:container
                                                                               attribute:NSLayoutAttributeRight
                                                                              multiplier:1.f constant:0.f];
    
    NSLayoutConstraint *heightLayoutConstraints = [NSLayoutConstraint constraintWithItem:_delegateOutputTextView
                                                                               attribute:NSLayoutAttributeHeight
                                                                               relatedBy:NSLayoutRelationEqual
                                                                                  toItem:nil
                                                                               attribute:NSLayoutAttributeNotAnAttribute
                                                                              multiplier:1.f constant:250.f];
    NSLayoutConstraint *leftTLayoutConstraints = [NSLayoutConstraint constraintWithItem:[self view]
                                                                              attribute:NSLayoutAttributeLeft
                                                                              relatedBy:NSLayoutRelationEqual
                                                                                 toItem:_delegateOutputTextView
                                                                              attribute:NSLayoutAttributeLeft
                                                                             multiplier:1.f constant:0.f];
    NSLayoutConstraint *rightTLayoutConstraints = [NSLayoutConstraint constraintWithItem:[self view]
                                                                               attribute:NSLayoutAttributeRight
                                                                               relatedBy:NSLayoutRelationEqual
                                                                                  toItem:_delegateOutputTextView
                                                                               attribute:NSLayoutAttributeRight
                                                                              multiplier:1.f constant:0.f];
    NSLayoutConstraint *bottomTLayoutConstraints = [NSLayoutConstraint constraintWithItem:_delegateOutputTextView
                                                                                attribute:NSLayoutAttributeBottom
                                                                                relatedBy:NSLayoutRelationEqual
                                                                                   toItem:[self view]
                                                                                attribute:NSLayoutAttributeBottom
                                                                               multiplier:1.f constant:0.f];
    
    NSDictionary *views = NSDictionaryOfVariableBindings(APITestTableView);
    [container addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:
                               @"H:|[APITestTableView]|" options:0 metrics:nil views:views]];
    [container addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:
                               @"V:|-40-[APITestTableView]-0-|" options:0 metrics:nil views:views]];
    
    [[self view] addConstraint:topCLayoutConstraints];
    [[self view] addConstraint:bottomCLayoutConstraints];
    [[self view] addConstraint:leftCLayoutConstraints];
    [[self view] addConstraint:rightCLayoutConstraints];
    [[self view] addConstraint:heightLayoutConstraints];
    [[self view] addConstraint:leftTLayoutConstraints];
    [[self view] addConstraint:rightTLayoutConstraints];
    [[self view] addConstraint:bottomTLayoutConstraints];
}

- (BOOL)textViewShouldBeginEditing:(UITextView *)textView {
    return NO;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:false];
    __weak typeof(self) weakSelf = self;
    switch (indexPath.row) {
        case 0: {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                [weakSelf parserWithDelegate];
            });
            break;
        }
        case 1: {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                [weakSelf parseInitialDataStream];
            });
            break;
        }
        case 2: {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                [weakSelf parseRemainingDataStream];
            });
            break;
        }
        case 3: {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_BACKGROUND, 0), ^{
                [weakSelf parseLargeDataStream];
            });
            break;
        }
        default:
            break;
    }
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [buttonArray count];
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSAttributedString* string = [[NSAttributedString alloc] initWithString:[buttonArray objectAtIndex:indexPath.row]];
    CGRect rect = [string boundingRectWithSize:CGSizeMake(100, 100) options:NSStringDrawingUsesDeviceMetrics context:nil];
    return rect.size.height + 40;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString* cellID = @"buttonCell";
    UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    [cell setBackgroundColor:[UIColor clearColor]];
    [[cell textLabel] setNumberOfLines:0];
    [[cell textLabel] setText:[buttonArray objectAtIndex:[indexPath row]]];
    [[cell textLabel] setTextAlignment:NSTextAlignmentCenter];
    return cell;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self constructViewWithTableView];
    [self setTitle:@"SBJson5StreamParser"];
    data = [NSMutableData data];
}

-(void)parserWithDelegate {
    id parser = [SBJson5StreamParser parserWithDelegate:self];
    id data = [@"[true,false]" dataUsingEncoding:NSUTF8StringEncoding];
    SBJson5ParserStatus parseStatus = [parser parse:data];
    NSMutableString* parseStatusString = [NSMutableString stringWithFormat:@"status for parsing is : %u",parseStatus];
    [self printColoredDebugInfo:parseStatusString using:[UIColor grayColor]];
}

-(void)parseInitialDataStream {
    id parser = [SBJson5StreamParser parserWithDelegate:self];
    NSString* dataStringBegin = [self readJsonFrom:@"test1_begin" withExtension:@"json"];
    
    [data appendData:[dataStringBegin dataUsingEncoding:NSUTF8StringEncoding]];
    SBJson5ParserStatus parseStatus = [parser parse:data];
    NSMutableString* parseStatusString = [NSMutableString stringWithFormat:@"Initial status for parsing is : %u",parseStatus];
    [self printColoredDebugInfo:parseStatusString using:[UIColor grayColor]];
}

-(void)parseRemainingDataStream {
    id parser = [SBJson5StreamParser parserWithDelegate:self];
    NSString* dataStringEnd = [self readJsonFrom:@"test1_end" withExtension:@"json"];
    
    [data appendData:[dataStringEnd dataUsingEncoding:NSUTF8StringEncoding]];
    SBJson5ParserStatus parseStatus = [parser parse:data];
    NSMutableString* parseStatusString = [NSMutableString stringWithFormat:@"Final status for parsing is : %u",parseStatus];
    [self printColoredDebugInfo:parseStatusString using:[UIColor grayColor]];
}

-(void)parseLargeDataStream {
    id parser = [SBJson5StreamParser parserWithDelegate:self];
    NSString* dataStringBegin = [self readJsonFrom:@"test2" withExtension:@"json"];
    
    id data = [dataStringBegin dataUsingEncoding:NSUTF8StringEncoding];
    SBJson5ParserStatus parseStatus = [parser parse:data];
    NSMutableString* parseStatusString = [NSMutableString stringWithFormat:@"status for parsing is : %u",parseStatus];
    [self printColoredDebugInfo:parseStatusString using:[UIColor grayColor]];
}

-(void)parserFoundObjectStart{
    __weak typeof(self) weakSelf = self;
    [weakSelf printColoredDebugInfo:@"parser found object start" using:[UIColor greenColor]];
}

-(void)parserFoundNull {
    __weak typeof(self) weakSelf = self;
    [weakSelf printColoredDebugInfo:@"parser found null object" using:[UIColor orangeColor]];
}

-(void)parserFoundError:(NSError *)err {
    __weak typeof(self) weakSelf = self;
    [weakSelf printColoredDebugInfo:[[NSString alloc] initWithFormat:@"parser found Error %@",err] using:[UIColor redColor]];
    [data setLength:0];
}

-(void)parserFoundNumber:(NSNumber *)num {
    __weak typeof(self) weakSelf = self;
    [weakSelf printColoredDebugInfo:[[NSString alloc] initWithFormat:@"%@",num] using:[UIColor blackColor]];
}

-(void)parserFoundString:(NSString *)string {
    __weak typeof(self) weakSelf = self;
    [weakSelf printColoredDebugInfo:[[NSString alloc] initWithFormat:@"%@",string] using:[UIColor blackColor]];
}

-(void)parserFoundArrayEnd {
    __weak typeof(self) weakSelf = self;
    [weakSelf printColoredDebugInfo:@"]" using:[UIColor brownColor]];
}

-(void)parserFoundBoolean:(BOOL)x {
    __weak typeof(self) weakSelf = self;
    [weakSelf printColoredDebugInfo:[[NSString alloc] initWithFormat:@"%@",(x ? @"true":@"false")] using:[UIColor magentaColor]];
}

-(void)parserFoundObjectEnd {
    __weak typeof(self) weakSelf = self;
    [weakSelf printColoredDebugInfo:@"parser found object end" using:[UIColor greenColor]];
}

-(void)parserFoundArrayStart {
    __weak typeof(self) weakSelf = self;
    [weakSelf printColoredDebugInfo:@"[" using:[UIColor brownColor]];
}

-(void)parserFoundObjectKey:(NSString *)key {
    __weak typeof(self) weakSelf = self;
    [weakSelf printColoredDebugInfo:[[NSString alloc] initWithFormat:@"%@",key] using:[UIColor orangeColor]];
}

@end
