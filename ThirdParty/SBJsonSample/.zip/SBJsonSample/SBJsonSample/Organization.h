//
//  Organization.h
//  SBJsonSample
//
//  Created by venkat kongara on 3/15/17.
//  Copyright © 2017 venkat kongara. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"

@interface Organization : NSObject

@property(atomic,strong) NSString* name;
@property(atomic,strong) NSArray<Person *>* people;

@end
