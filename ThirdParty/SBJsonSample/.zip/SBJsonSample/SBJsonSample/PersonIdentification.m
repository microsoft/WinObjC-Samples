//
//  PersonIdentification.m
//  SBJsonSample
//
//  Created by venkat kongara on 3/15/17.
//  Copyright © 2017 venkat kongara. All rights reserved.
//

#import "PersonIdentification.h"

@implementation PersonIdentification

- (id)proxyForJson {
   return [NSDictionary dictionaryWithObjectsAndKeys:
                       self.speciality, @"speciality",
                       [[NSNumber alloc] initWithLong:self.identifier], @"UUID",
                       nil];
}

@end
