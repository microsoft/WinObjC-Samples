//
//  PersonIdentification.h
//  SBJsonSample
//
//  Created by venkat kongara on 3/15/17.
//  Copyright © 2017 venkat kongara. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PersonIdentification : NSObject

@property(atomic) long identifier;
@property(atomic,strong) NSString* speciality;

@end
