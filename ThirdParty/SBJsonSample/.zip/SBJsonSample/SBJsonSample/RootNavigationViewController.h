//
//  RootNavigationViewController.h
//  SBJsonSample
//
//  Created by venkat kongara on 3/14/17.
//  Copyright © 2017 venkat kongara. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RootNavigationViewController : UINavigationController

@end
