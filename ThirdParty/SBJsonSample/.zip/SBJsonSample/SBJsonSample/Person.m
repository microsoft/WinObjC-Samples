//
//  Person.m
//  SBJsonSample
//
//  Created by venkat kongara on 3/15/17.
//  Copyright © 2017 venkat kongara. All rights reserved.
//

#import "Person.h"

@implementation Person

- (id)proxyForJson {
    return [NSDictionary dictionaryWithObjectsAndKeys:
            _personalDetails, @"personalDetails",
            _personIdentification, @"personIdentification",
            nil];
}

@end
