//
//  Person.h
//  SBJsonSample
//
//  Created by venkat kongara on 3/15/17.
//  Copyright © 2017 venkat kongara. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "PersonIdentification.h"
#import "PersonalDetails.h"

@interface Person : NSObject

@property(atomic,strong) PersonalDetails* personalDetails;
@property(atomic,strong) PersonIdentification* personIdentification;

@end
