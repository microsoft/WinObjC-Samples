//
//  ListViewController.m
//  SBJsonSample
//
//  Created by venkat kongara on 3/14/17.
//  Copyright © 2017 venkat kongara. All rights reserved.
//

#import "ListViewController.h"
#import "ParserViewController.h"
#import "StreamParserViewController.h"
#import "WriterViewController.h"
#import "StreamWriterViewController.h"

@interface ListViewController (){
    NSArray* buttonArray;
}

@end

@implementation ListViewController

-(void)constructViewWithTableView {
    
    UILabel* label = [[UILabel alloc] init];
    [label setText:@"SBJson5 API Usage Test Application."];
    [label setLineBreakMode:NSLineBreakByWordWrapping];
    [label setNumberOfLines:0];
    [label setTranslatesAutoresizingMaskIntoConstraints:NO];
    [label setBackgroundColor:[UIColor lightGrayColor]];
    [label setTextColor:[UIColor whiteColor]];
    [label setTextAlignment:NSTextAlignmentCenter];
    [[self view] addSubview:label];
    
    buttonArray = [[NSArray alloc] initWithObjects:@"SBJson5Parser",@"SBJson5StreamParser",@"SBJson5Writer",@"SBJson5StreamWriter",nil];
    UITableView* APITestTableView = (UITableView*)[[UITableView alloc] init];
    APITestTableView.delegate = self;
    APITestTableView.dataSource = self;
    APITestTableView.translatesAutoresizingMaskIntoConstraints = false;
    APITestTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    [[self view] addSubview:APITestTableView];
    
    id topGuide = self.topLayoutGuide;
    
    
    NSDictionary *views = NSDictionaryOfVariableBindings(label,APITestTableView,topGuide);
    [[self view] addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:
                                 @"H:|[APITestTableView]|" options:0 metrics:nil views:views]];
    [[self view] addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:
                                 @"H:|[label]|" options:0 metrics:nil views:views]];
    [[self view] addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:
                                 @"V:|[topGuide][label(40)][APITestTableView]-0-|" options:0 metrics:nil views:views]];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self constructViewWithTableView];
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:false];
    switch (indexPath.row) {
        case 0:            
            [[self navigationController] pushViewController:[[ParserViewController alloc] init] animated:true];
            break;
        case 1:
            [[self navigationController] pushViewController:[[StreamParserViewController alloc] init] animated:true];
            break;
        case 2:
            [[self navigationController] pushViewController:[[WriterViewController alloc] init] animated:true];
            break;
        case 3:
            [[self navigationController] pushViewController:[[StreamWriterViewController alloc] init] animated:true];
            break;
        default:
            break;
    }
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [buttonArray count];
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSString* cellID = @"buttonCell";
    UITableViewCell* cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    [[cell textLabel] setText:[buttonArray objectAtIndex:[indexPath row]]];
    [[cell textLabel] setTextAlignment:NSTextAlignmentCenter];
    [[cell textLabel] setNumberOfLines:0];
    [cell setBackgroundColor:[UIColor clearColor]];
    return cell;
}

@end
