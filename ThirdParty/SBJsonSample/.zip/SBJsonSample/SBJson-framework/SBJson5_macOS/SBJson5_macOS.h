//
//  SBJson5_macOS.h
//  SBJson5_macOS
//
//  Created by Stig Brautaset on 28/10/2016.
//
//

#import <Cocoa/Cocoa.h>

//! Project version number for SBJson5_macOS.
FOUNDATION_EXPORT double SBJson5_macOSVersionNumber;

//! Project version string for SBJson5_macOS.
FOUNDATION_EXPORT const unsigned char SBJson5_macOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SBJson5_macOS/PublicHeader.h>


